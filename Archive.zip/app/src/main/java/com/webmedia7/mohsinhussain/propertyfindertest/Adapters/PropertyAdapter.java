package com.webmedia7.mohsinhussain.propertyfindertest.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.webmedia7.mohsinhussain.propertyfindertest.Modals.Property;
import com.webmedia7.mohsinhussain.propertyfindertest.R;

import java.util.ArrayList;

/**
 * Created by mohsinhussain on 6/16/15.
 */
public class PropertyAdapter extends BaseAdapter{

    /************** Declare used variables ******************/
    private Activity activity;
    private ArrayList<Property> data;
    private static LayoutInflater inflater = null;
    Property tempValues = null;
    private static final int ITEM_VIEW_TYPE_1 = 0;
    private static final int ITEM_VIEW_TYPE_2 = 1;


    /*************  CustomAdapter Constructor *****************/
    public PropertyAdapter(Activity a, ArrayList<Property> d, String action) {

        /********** Take passed values **********/
        activity = a;
        data=d;
        /***********  Layout inflator to call external xml layout () ***********/
        inflater = ( LayoutInflater )activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Property getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /** THIS SOLVED SCROLLING ISSUE WITH FALSE VALUES **/
    @Override
    public int getItemViewType(int position) {
        return this.getItem(position).isVisited() ? ITEM_VIEW_TYPE_1 : ITEM_VIEW_TYPE_2;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }



    /********* Create a holder Class to contain inflated xml file elements *********/
    private static class ViewHolder{

        public TextView priceTextView;
        public TextView currencyTextView;
        public TextView titleTextView;
        public TextView addressTextView;
        public ImageView imageView;

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;

        if(convertView==null){

            /****************** Inflate list_row.xml for each row ******************/
            vi = inflater.inflate(R.layout.list_row_property, null);


            /****************** View Holder Object to contain list_row.xml file elements *******************/
            holder = new ViewHolder();
            holder.priceTextView = (TextView) vi.findViewById(R.id.priceTextView);
            holder.currencyTextView = (TextView) vi.findViewById(R.id.currencyTextView);
            holder.titleTextView = (TextView) vi.findViewById(R.id.titleTextView);
            holder.addressTextView = (TextView) vi.findViewById(R.id.addressTextView);
            holder.imageView = (ImageView) vi.findViewById(R.id.imageView);

            /************  Set holder with LayoutInflater ************/
            vi.setTag(holder);
        } else {
            holder = (ViewHolder) vi.getTag();
        }

        if(data.size()<=0){
//            holder.nameTextView.setText("Please Add Contacts.");
//            holder.profileImageView.setVisibility(View.GONE);
        }
        else{
            /****************** Get Each Model Object From Array List *******************/
            tempValues = null;
            tempValues = (Property) data.get(position);

            /****************** Set Model Values in Holder Elements *****************/
            holder.priceTextView.setText(tempValues.getPrice()+"/year");
            holder.currencyTextView.setText(tempValues.getCurrency());
            holder.titleTextView.setText(tempValues.getTitle());
            holder.addressTextView.setText(tempValues.getLocation());
        }



        return vi;
    }
}
